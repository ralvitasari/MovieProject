package com.android.movieproject.movie.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.movieproject.movie.model.MovieReviewResponse
import com.android.movieproject.movie.model.MoviesDetailResponse
import com.android.movieproject.movie.presenter.DetailPresenter

class DetailViewModel:ViewModel(), DetailPresenter.State {

    val error = MutableLiveData<String>()
    val movieDtl = MutableLiveData<MoviesDetailResponse>()
    val movieReviewResponse = MutableLiveData<MovieReviewResponse>()


    override fun error (reason : String) {
        error.value = reason
    }

    override fun movieDetailFetched(movieDetail: MoviesDetailResponse) {
        movieDtl.value = movieDetail
    }

    override fun movieReviewFetched(movieReview: MovieReviewResponse) {
        movieReviewResponse.value = movieReview
    }

}