package com.android.movieproject.movie.view

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProviders
import com.android.movieproject.movie.adapter.ReviewAdapter
import com.android.movieproject.movie.model.Country
import com.android.movieproject.movie.model.Genre
import com.android.movieproject.movie.model.MovieReviewResponse
import com.android.movieproject.movie.model.MoviesDetailResponse
import com.android.movieproject.movie.presenter.DetailPresenter
import com.android.movieproject.movie.repository.database.MovieRepository.baseImage
import com.android.movieproject.movie.viewmodel.DetailViewModel
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.movieproject.R
import com.example.movieproject.databinding.ActivityDetailBinding
import com.google.android.material.snackbar.Snackbar
import java.util.Locale

class DetailActivity : BaseActivity() {

    private lateinit var detailBinding: ActivityDetailBinding
    private lateinit var detailViewModel: DetailViewModel
    private lateinit var presenter: DetailPresenter
    private val reviewAdapter = ReviewAdapter(rContext)
    private lateinit var rContext: Context

    companion object {
        var titleDtl = ""
        var idDtl : Int = 0

        fun start(context: Context, idDetail: Int?, detailTitle: String? ): Intent {
            val intentDtl = Intent(context, DetailActivity::class.java)
            idDtl = idDetail?: 0
            titleDtl = detailTitle?: ""
            return intentDtl
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailBinding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(detailBinding.root)


        setToolbar()
        setViewModel()
        setPresenter()
        setupRefreshLayout()

        observe(detailViewModel.error, this::whenErrorChanged)
        observe(detailViewModel.movieDtl, this::whenMovieListChanged)
        observe(detailViewModel.movieReviewResponse, this::whenReviewsListChanged)
        }
    private fun setToolbar(){
        val st = supportActionBar
        st?.title = titleDtl
        st?.setDisplayHomeAsUpEnabled(true)
    }

    private fun setViewModel() {
        detailViewModel = ViewModelProviders.of(this).get(DetailViewModel::class.java)
    }

    private fun setPresenter() {
        presenter = DetailPresenter(detailViewModel)
        presenter.setup(idDtl)
    }

    private fun setupRefreshLayout() {
        detailBinding.apply {
            DetailMovieSrl.setColorSchemeColors(ContextCompat.getColor(rContext, R.color.colorPrimary))
            DetailMovieSrl.setOnRefreshListener {
                presenter.fetch()
            }
        }
    }

    private fun whenErrorChanged(reason: String) {
        detailBinding.apply {
            DetailMovieSrl.isRefreshing = false
            Snackbar.make(findViewById(android.R.id.content), reason, Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun whenMovieListChanged(movieDetail: MoviesDetailResponse) {
        detailBinding.apply {
            DetailMovieSrl.isRefreshing = false
            Glide.with(this@DetailActivity).load(baseImage + movieDetail.posterPath).apply(RequestOptions().centerCrop().error(R.drawable.ic_placeholder).placeholder(R.drawable.ic_placeholder)).into(DetailPosterIv)
            Glide.with(this@DetailActivity).load(baseImage + movieDetail.backdropPath).apply(RequestOptions().centerCrop().error(R.drawable.ic_placeholder).placeholder(R.drawable.ic_placeholder)).into(DetailBackdropIv)

            DetailTitleTv.text = movieDetail.title
            DtlOriginalTitleTv.text = movieDetail.originalTitle
            DetailCountryTv.text = setAllFlagEmoticonCountries(movieDetail.productionCountries ?: arrayListOf())

            val loc = Locale(movieDetail.originalLanguage)
            val lang = loc.displayLanguage
            DtlOriginalTitleTv.text = lang
            DtlNetworkTv.text = getString(movieDetail.runtime ?: 0)
            DtlMovieGenreTv.text = setAllGenres(movieDetail.genres ?: arrayListOf())
            DylMovieSinopTv.text = movieDetail.overview ?: "-"
        }
    }

    private fun whenReviewsListChanged(movieReview: MovieReviewResponse) {
        detailBinding.apply {
            DetailMovieSrl.isRefreshing = false
            DtlReviewRv.layoutManager = CustomLinearLayoutManager(this@DetailActivity)
            DtlReviewRv.adapter = reviewAdapter
            reviewAdapter.footerLayout = R.layout.nothing
            reviewAdapter.items = movieReview.results ?: arrayListOf()
            if (reviewAdapter.items.count() == 0) DtlEmptyReviewTv.visibility = View.VISIBLE
            else DtlEmptyReviewTv.visibility = View.GONE
        }

    }

    private fun setAllFlagEmoticonCountries(countries: List<Country>): String {
        val country = StringBuilder()
        if (countries.size > 0) {
            for (coun in countries) {
                country.append(flagCountry(coun.iso3166_1)).append(", ")
            }
            country.deleteCharAt(country.lastIndexOf(","))
        } else {
            country.append(flagCountry("XX"))
        }
        return country.toString()
    }

    private fun flagCountry(code: String?): String {
        val flagOffset = 0x1F1E6
        val asciiOffset = 0x41

        val firstChar = Character.codePointAt(code as CharSequence, 0) - asciiOffset + flagOffset
        val secondChar = Character.codePointAt(code as CharSequence, 1) - asciiOffset + flagOffset

        return String(Character.toChars(firstChar)) + String(Character.toChars(secondChar)) + " " + code
    }

    private fun setAllGenres(genres: List<Genre>): String {
        val genress = StringBuilder()
        if (genres.size > 0) {
            for (gen in genres) {
                genress.append(gen.name).append(", ")
            }
            genress.deleteCharAt(genress.lastIndexOf(","))
        } else {
            genress.append("-")
        }
        return genress.toString()
    }

}
