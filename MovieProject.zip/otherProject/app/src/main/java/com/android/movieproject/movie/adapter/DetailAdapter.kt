package com.android.movieproject.movie.adapter

class DetailAdapter {
}