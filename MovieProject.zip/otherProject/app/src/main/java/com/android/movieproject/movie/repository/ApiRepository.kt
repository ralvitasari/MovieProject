package com.android.movieproject.movie.repository

import com.android.movieproject.movie.model.GenreResponse
import com.android.movieproject.movie.model.MovieResponse
import com.android.movieproject.movie.model.MovieReviewResponse
import com.android.movieproject.movie.model.MoviesDetailResponse
import io.reactivex.Observable


interface ApiRepository {
    fun genre(token: String): io.reactivex.Observable<GenreResponse>

    fun movie(token: String, region: String, movieFilter: MovieFilter) : Observable<MovieResponse>

    fun movieDetail(token: String, id: Int, append_to_response: String) : Observable<MoviesDetailResponse>

    fun movieReview(token: String, id: Int) : Observable<MovieReviewResponse>

    data class MovieFilter(
        val genre: Int,
        var page: Int = 1
    )
}