package com.android.movieproject.movie

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.movieproject.movie.view.MovieActivity
import com.android.movieproject.util.navigateToMovieActivity
import com.example.movieproject.R
import com.example.movieproject.databinding.ActivityDetailBinding
import com.example.movieproject.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var mainBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)

        mainBinding.apply {
            menuBtn.setOnClickListener{
                navigateToMovieActivity(this@MainActivity)
            }
        }
    }
}