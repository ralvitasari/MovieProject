package com.android.movieproject.movie.view

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.lifecycle.ViewModelProviders
import com.android.movieproject.movie.presenter.MoviePresenter
import com.android.movieproject.movie.viewmodel.MovieViewModel
import com.example.movieproject.databinding.ActivityGenreBinding

class MovieActivity : BaseActivity() {

    private lateinit var genreBinding: ActivityGenreBinding
    private lateinit var movieViewModel: MovieViewModel
    private lateinit var presenter: MoviePresenter

    companion object {
        var titleMovie = ""
        var genre : Int = 0

        fun start(context: Context, genreMovieVal: Int, genreTitle: String): Intent {
            val intent = Intent (context, MovieActivity::class.java)
            genre = genreMovieVal
            titleMovie = genreTitle
            return intent
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        genreBinding =ActivityGenreBinding.inflate(layoutInflater)
        setContentView(genreBinding.root)

        setupToolbar()
        setupViewModel()

    }

    private fun setupToolbar(){
        val ab = supportActionBar
        ab?.title = titleMovie
        ab?.setDisplayHomeAsUpEnabled(true)
    }

    private fun setupViewModel() {
        movieViewModel = ViewModelProviders.of(this).get(MovieViewModel::class.java)
    }

    private fun setupPresenter() {
        presenter = MoviePresenter(movieViewModel)
        presenter.setup(genre)
    }
}