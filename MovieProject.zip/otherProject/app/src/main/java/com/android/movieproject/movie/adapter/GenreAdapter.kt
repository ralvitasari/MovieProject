package com.android.movieproject.movie.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.movieproject.movie.model.Genre
import com.android.movieproject.movie.view.MovieActivity
import com.example.movieproject.databinding.ItemListGenreBinding


class GenreAdapter (
    private val context: Context
    ): RecyclerView.Adapter<GenreAdapter.ViewHolder>() {
    private var listData = ArrayList<Genre> ()

    inner class ViewHolder (private val binding: ItemListGenreBinding)
        : RecyclerView.ViewHolder(binding.root) {
            fun bind(data: Genre, position: Int) {
                binding.apply {
                    //todo
                    genreListIlgTv.text = data.name
                    genreListIlgCv.setOnClickListener {
                        context.startActivity(
                            MovieActivity.start(context = context,
                                genreMovieVal = data.id , genreTitle = data.name)
                        )
                    }
                }
            }
        }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int): ViewHolder {
        val view = ItemListGenreBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: GenreAdapter.ViewHolder, position: Int) {
        //todo
        holder.bind(listData[position], position)
    }

    override fun getItemCount() = listData.size

    override fun getItemViewType(position: Int) = position

    override fun setHasStableIds(hasStableIds: Boolean) {
        super.setHasStableIds(true)
    }

}
