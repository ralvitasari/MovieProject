package com.android.movieproject.movie.repository

import com.android.movieproject.movie.repository.database.MovieRepository

object InstanceRepository{
    val default: ApiRepository = MovieRepository
}