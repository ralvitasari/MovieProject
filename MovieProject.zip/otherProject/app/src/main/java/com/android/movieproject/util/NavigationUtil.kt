package com.android.movieproject.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.android.movieproject.movie.view.MovieActivity

fun navigateToMovieActivity(context: Context) {
    if (context is Activity) {
        val flags = context.flags(Intent.FLAG_ACTIVITY_NEW_TASK, Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.start<MovieActivity>(flags)
    }
}

private fun <T> Activity.start(flags: Int) {

}
