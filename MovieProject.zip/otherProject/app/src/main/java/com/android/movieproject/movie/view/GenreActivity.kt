package com.android.movieproject.movie.view

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProviders
import com.android.movieproject.movie.presenter.GenrePresenter
import com.android.movieproject.movie.viewmodel.GenreViewModel
import com.example.movieproject.R
import com.example.movieproject.databinding.ActivityGenreBinding
import com.google.android.material.snackbar.Snackbar

class GenreActivity : AppCompatActivity() {
    private lateinit var genreBinding: ActivityGenreBinding
    private lateinit var genreViewModel: GenreViewModel
    private lateinit var presenter: GenrePresenter
    private lateinit var rContext:Context


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        genreBinding = ActivityGenreBinding.inflate(layoutInflater)
        setContentView(genreBinding.root)

        setupViewModel()
        setupPresenter()
//        setupRecyclerView()
        setupRefreshLayout()

        presenter.fetch()
//
//        observe(viewModel.error, this::whenErrorChanged)
//        observe(viewModel.genreList, this::whenGenreListChanged)
    }

    private fun setupViewModel() {
        genreViewModel = ViewModelProviders.of(this).get(GenreViewModel::class.java)
    }

    private fun setupPresenter() {
        presenter = GenrePresenter(genreViewModel)
    }

//    private fun setupRecyclerView() {
//        rvGenre.layoutManager = CustomLinearLayoutManager(this)
//        rvGenre.adapter = adapter
//        adapter.footerLayout = R.layout.progress
//    }

    private fun setupRefreshLayout() {
        genreBinding.apply {
            genreBinding.GenreListSrl.setColorSchemeColors(ContextCompat.getColor(rContext, R.color.colorPrimary))
            genreBinding.GenreListSrl?.setOnRefreshListener {
                presenter.fetch()
            }
        }
    }

//    private fun whenErrorChanged(reason: String) {
//        srlGenre.isRefreshing = false
//        adapter.footerLayout = if (adapter.items.count() == 0) R.layout.empty else R.layout.nothing
//        Snackbar.make(findViewById(android.R.id.content), reason, Snackbar.LENGTH_SHORT).show()
//    }

//    private fun whenGenreListChanged(billingList: List<Genre>) {
//        srlGenre.isRefreshing = false
//        adapter.items = billingList
//        adapter.footerLayout = if (adapter.items.count() == 0) R.layout.empty else R.layout.nothing
//        if (adapter.items.count() <= 20) {
//            rvGenre.scrollToPosition(0)
//        }
//    }
}