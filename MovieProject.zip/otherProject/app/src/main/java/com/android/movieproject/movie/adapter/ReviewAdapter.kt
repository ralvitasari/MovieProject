package com.android.movieproject.movie.adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.android.movieproject.movie.model.Review
import com.example.movieproject.databinding.ItemListReviewBinding


class ReviewAdapter (
    private val context: Context
): RecyclerView.Adapter<ReviewAdapter.ViewHolder>() {
    lateinit var items: List<Review>
    var footerLayout: Int = 0
    private var listData = ArrayList<Review> ()

    inner class ViewHolder (private val binding: ItemListReviewBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun bind(data: Review, position: Int) {
            binding.apply {
                //todo
                ReviewAuthorTv.text = data.author
//                tvReviewContent.setOnClickListener {
//                    context.startActivity(
//                        MovieActivity.start(context = context,
//                            genreMovieVal = data.id , genreTitle = data.name)
//                    )
//                }
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int): ReviewAdapter.ViewHolder {
        val view = ItemListReviewBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(view)
    }

    fun onBindFooter(itemView: View) {

    }

    override fun onBindViewHolder(holder: ReviewAdapter.ViewHolder, position: Int) {
        //todo
        holder.bind(listData[position], position)
    }

    override fun getItemCount() = listData.size

    override fun getItemViewType(position: Int) = position

    override fun setHasStableIds(hasStableIds: Boolean) {
        super.setHasStableIds(true)
    }
}