package com.android.movieproject.movie.adapter

class MovieAdapter {
}