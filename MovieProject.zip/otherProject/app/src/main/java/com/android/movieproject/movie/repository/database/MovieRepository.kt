package com.android.movieproject.movie.repository.database


import com.android.movieproject.movie.model.GenreResponse
import com.android.movieproject.movie.model.MovieResponse
import com.android.movieproject.movie.model.MovieReviewResponse
import com.android.movieproject.movie.model.MoviesDetailResponse
import com.android.movieproject.movie.repository.ApiRepository
import com.android.movieproject.util.PaginationDidEnd
import com.android.movieproject.util.UnexpectedResponseFromServer
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.QueryMap
import io.reactivex.Observable
import retrofit2.http.Path

object MovieRepository : ApiRepository {

    const val token = "a189ab00d75b2e9c05fa5040a8db41b7"
    const val baseURL = "https://api.themoviedb.org/3/"
    const val baseImage = "http://image.tmdb.org/t/p/w500"
    const val youtubeKey = "AIzaSyC320_WDKC2bbdwep2_WQT3Mj-dA_Pw_-o"


    private val interceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val client = OkHttpClient.Builder().apply {
        addInterceptor(interceptor)
    }.build()

    private val instance: Specification = Retrofit.Builder()
        .baseUrl(baseURL)
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .client(client)
        .build()
        .create(Specification::class.java)

    private interface Specification {

        @GET("genre/movie/list")
        fun getGenreList(
            @Query("api_key") api: String
        ): Observable<GenreResponse>

        @GET("discover/movie")
        fun getMovieList(
            @Query("api_key") api: String,
            @Query("region") region: String,
            @QueryMap queries: Map<String, String?>
        ): io.reactivex.Observable<MovieResponse>

        @GET("movie/{id}")
        fun getMovieDetail(
            @Path("id") id: String,
            @Query("api_key") api: String,
            @Query("append_to_response") appendToResponse: String
        ): Observable<MoviesDetailResponse>

        @GET("movie/{id}/reviews")
        fun getMovieReview(@Path("id") id: String,
                           @Query("api_key") api: String
        ): Observable<MovieReviewResponse>
    }

    override fun genre(token: String): io.reactivex.Observable<GenreResponse> {
        return instance.getGenreList(token).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .map { it }
    }

    override fun movie(
        token: String,
        region: String,
        movieFilter: ApiRepository.MovieFilter
    ): io.reactivex.Observable<MovieResponse> {
        val parameters = hashMapOf<String, String>()
        parameters["with_genres"] = movieFilter.genre.toString()
        parameters["page"] = movieFilter.page.toString()
        return instance.getMovieList(token, region, parameters)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .map {
                val pageCount = it.total_pages ?: throw UnexpectedResponseFromServer()
                if (pageCount < movieFilter.page) {
                    throw PaginationDidEnd()
                }
                it
            }
    }

     override fun movieDetail(
        token: String,
        id: Int,
        append_to_response: String
    ): Observable<MoviesDetailResponse> {
        return instance.getMovieDetail(id.toString(),token, append_to_response)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .map { it }
    }

     override fun movieReview(token: String, id: Int): Observable<MovieReviewResponse> {
        return instance.getMovieReview(id.toString(), token)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .map { it }
    }
}