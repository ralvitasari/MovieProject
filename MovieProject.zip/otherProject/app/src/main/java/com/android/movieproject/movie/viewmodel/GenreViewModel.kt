package com.android.movieproject.movie.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.movieproject.movie.model.Genre
import com.android.movieproject.movie.model.GenreResponse
import com.android.movieproject.movie.presenter.GenrePresenter


class GenreViewModel : ViewModel(), GenrePresenter.State  {
    val error = MutableLiveData<String>()
    val genreList = MutableLiveData<List<Genre>>()

    override fun error (reason:String) {
        error.value = reason
    }

    override fun genreFetched(genre: GenreResponse) {
        val items = ArrayList<Genre> ()
        items.addAll(genre.genres)
        genreList.value = items
    }
}