package com.android.movieproject.movie.presenter

import com.android.movieproject.movie.model.MovieReviewResponse
import com.android.movieproject.movie.model.MoviesDetailResponse
import com.android.movieproject.movie.repository.InstanceRepository
import com.android.movieproject.movie.repository.database.MovieRepository.token
import io.reactivex.disposables.Disposable

class DetailPresenter(private val state: State) {

    private var idDtl = 0
    private var onGoingRequest: Disposable?= null
    private val append = "videos"

    fun setup(idDetail: Int) {
        this.idDtl = idDetail
    }

    fun fetch() {
        onGoingRequest?.dispose()
        onGoingRequest = InstanceRepository.default.movieDetail(token, idDtl, append)
            .subscribe({state.movieDetailFetched(it)},{state
                .error(it.localizedMessage ?: "Unknown")})

    }

    fun fetchReview() {
        onGoingRequest?.dispose()
        onGoingRequest = InstanceRepository.default.movieReview(token, idDtl)
            .subscribe({state.movieReviewFetched(it)},{state
                .error(it.localizedMessage ?: "Unknown")})

    }

    interface State {
        fun error(reason: String)

        fun movieDetailFetched(movieDetail: MoviesDetailResponse)

        fun movieReviewFetched(movieReview: MovieReviewResponse)
    }
}