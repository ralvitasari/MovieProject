package com.android.movieproject.movie.presenter

import com.android.movieproject.movie.model.GenreResponse
import com.android.movieproject.movie.repository.InstanceRepository
import com.android.movieproject.movie.repository.database.MovieRepository.token

import io.reactivex.disposables.Disposable

class GenrePresenter(private val state: State) {

    private var onGoingRequest: Disposable?= null

    fun fetch() {
        onGoingRequest?.dispose()
        onGoingRequest = InstanceRepository.default.genre(token).subscribe({state.genreFetched(it)},{state.error(it.localizedMessage ?: "Unknonw")})

    }

    interface State {
        fun error(reason: String)

        fun genreFetched(genre: GenreResponse)
    }
}