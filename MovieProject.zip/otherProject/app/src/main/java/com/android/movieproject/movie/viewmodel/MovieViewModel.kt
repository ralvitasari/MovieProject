package com.android.movieproject.movie.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.movieproject.movie.model.MovieResponse
import com.android.movieproject.movie.presenter.MoviePresenter

class MovieViewModel : ViewModel(), MoviePresenter.State {

    val error = MutableLiveData<String>()
    val movieList = MutableLiveData<List<MovieResponse>>()
    val paginationHasEnded = MutableLiveData<Boolean>()

     override fun error(reason: String) {
        error.value = reason
    }

     override fun movieFetched(model: MovieResponse) {
        val items = ArrayList<MovieResponse>()
        val existingItems = movieList.value ?: listOf()
        items.addAll(existingItems)
        items.addAll(model.results)
        movieList.value = items
    }

     override fun paginationHasEnded() {
        paginationHasEnded.value = true
    }

    override fun paginationWasEnd(): Boolean {
        return paginationHasEnded.value ?: false
    }

}